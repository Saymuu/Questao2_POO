﻿public class Montador
{
    private PilhaDePecas pilhaDePecas;

    public Montador()
    {
        pilhaDePecas = new PilhaDePecas();
    }

    public void MontarVentilador()
    {
        pilhaDePecas.Empilhar(new Peca("Cúpula de Vidro"));
        pilhaDePecas.Empilhar(new Peca("Lâmpada"));
        pilhaDePecas.Empilhar(new Peca("Hélice Quebrada"));
        pilhaDePecas.Empilhar(new Peca("Suporte"));
    }

    public void SubstituirPeca(string nomePecaVelha, string nomePecaNova)
    {
        pilhaDePecas.SubstituirPeca(nomePecaVelha, nomePecaNova);
    }

    public void ExibirPilha()
    {
        pilhaDePecas.MostrarPilha();
    }
}
