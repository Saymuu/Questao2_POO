﻿using System;
using System.Collections.Generic;

public class PilhaDePecas
{
    private Stack<Peca> pilha;

    public PilhaDePecas()
    {
        pilha = new Stack<Peca>();
    }

    public void Empilhar(Peca peca)
    {
        pilha.Push(peca);
    }

    public Peca Desempilhar()
    {
        return pilha.Count > 0 ? pilha.Pop() : null;
    }


    public void SubstituirPeca(string nomePecaVelha, string nomePecaNova)
    {
        Stack<Peca> pecasTemp = new Stack<Peca>();


        while (pilha.Count > 0)
        {
            Peca pecaAtual = Desempilhar();
            if (pecaAtual.Nome == nomePecaVelha)
            {
                pecasTemp.Push(new Peca(nomePecaNova));
                break;
            }
            else
            {
                pecasTemp.Push(pecaAtual);
            }
        }

        while (pecasTemp.Count > 0)
        {
            Empilhar(pecasTemp.Pop());
        }
    }

    public void MostrarPilha()
    {
        Console.WriteLine("Estado atual da pilha:");
        foreach (var peca in pilha)
        {
            Console.WriteLine(peca);
        }
    }
}
